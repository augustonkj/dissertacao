package com.construtortelas

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
