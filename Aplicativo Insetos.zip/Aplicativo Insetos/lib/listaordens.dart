class ListaOrdens {
  List<String> listaordens = [];

  ListaOrdens() {
    listaordens.add("Hexapoda");
    listaordens.add("Archaeognatha");
    listaordens.add("Blattaria");
    listaordens.add("Coleoptera");
    listaordens.add("Collembola");
    listaordens.add("Dermaptera");
    listaordens.add("Diplura");
    listaordens.add("Diptera");
    listaordens.add("Embioptera");
    listaordens.add("Ephemeroptera");
    listaordens.add("Auchenorrhyncha"); //subordem
    listaordens.add("Sternorrhyncha"); //subordem
    listaordens.add("Heteroptera"); //subordem
    listaordens.add("Hymenoptera");
    listaordens.add("Isoptera");
    listaordens.add("Lepidoptera");
    listaordens.add("Mantodea");
    listaordens.add("Mecoptera");
    listaordens.add("Megaloptera");
    listaordens.add("Neuroptera");
    listaordens.add("Odonata");
    listaordens.add("Orthoptera");
    listaordens.add("Phasmatodea");
    listaordens.add("Phthiraptera");
    listaordens.add("Plecoptera");
    listaordens.add("Protura");
    listaordens.add("Psocoptera");
    listaordens.add("Siphonaptera");
    listaordens.add("Strepsiptera");
    listaordens.add("Thysanoptera");
    listaordens.add("Trichoptera");
    listaordens.add("Zoraptera");
    listaordens.add("Zygentoma");
  }
}
