class infoDisponibilidade {
  final List<int> disponibilidade = [
    5, // Hexapoda
    5, //Archaeognatha
    5, //Blattaria
    5, //Coleoptera
    5, //Collembola
    5, //Dermaptera
    5, //Diplura
    5, //Diptera
    5, //Embioptera
    5, //Ephemeroptera
    5, //Auchenorrhyncha
    5, //Sternorrhyncha
    5, //Heteroptera
    5, //Hymenoptera
    5, //Isoptera
    5, //Lepidoptera
    5, //Mantodea
    5, //Mecoptera
    3, //Megaloptera
    5, //Neuroptera
    5, //Odonata
    5, //Orthoptera
    5, //Phasmatodea
    5, //Phthiraptera
    5, //Plecoptera
    5, //Protura
    5, //Psocoptera
    3, //Siphonaptera
    2, //Strepsiptera
    5, //Thysanoptera
    5, //Trichoptera
    1, //Zoraptera
    5 //Zygentoma
  ];
}

