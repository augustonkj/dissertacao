
import 'package:flutter/material.dart';

import 'referencias_body.dart';


class referencias_screen extends StatelessWidget {


  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(


      body: referencias_body(),


    );
  }


}
