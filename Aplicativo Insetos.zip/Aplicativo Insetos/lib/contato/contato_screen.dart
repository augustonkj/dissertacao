
import 'package:flutter/material.dart';

import 'contato.dart';


class contatoscreen extends StatelessWidget {


  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(


      body: contato(),


    );
  }


}
